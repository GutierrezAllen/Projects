/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Customer;

import java.sql.*;
import java.util.*;


/**
 *
 * @author ccslearner
 */
public class Customer_d {
    
    public int customerid;
    public String firstname;
    public String middlename;
    public String lastname;
    public int mobile_number;
    public String email;
    public int destinationid;    
    
    public ArrayList<Integer> customerIdList = new ArrayList<> ();
    public ArrayList<String> customerFNameList = new ArrayList<> ();
    public ArrayList<String> customerMNameList = new ArrayList<> ();
    public ArrayList<String> customerLNameList = new ArrayList<> ();
    public ArrayList<Integer> customerMobileList = new ArrayList<> ();
    public ArrayList<String> customerEmailList = new ArrayList<> ();
    
    public ArrayList<Integer> destinationIDList = new ArrayList<> ();
    
    public Customer_d() {}
    
    public int display_customer(){
         try {
             Connection conn;
         
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
           System.out.println("Connection Successful");
           
           PreparedStatement pstmt = conn.prepareStatement("SELECT customerid, lastname, middlename, firstname, destinationid, mobile_number, email FROM Customer;");
           ResultSet rst = pstmt.executeQuery();
           
           customerIdList.clear();
           customerLNameList.clear();
           customerMNameList.clear();
           customerFNameList.clear();
           destinationIDList.clear();
           customerMobileList.clear();
           customerEmailList.clear();
           
            while(rst.next()){
                customerid = rst.getInt("customerid");
                lastname = rst.getString("lastname");
                middlename = rst.getString("middlename");
                firstname = rst.getString("firstname");
                destinationid = rst.getInt("destinationid");
                mobile_number = rst.getInt("mobile_number");
                email = rst.getString("email");
                
                customerIdList.add(customerid);
                customerLNameList.add(lastname);
                customerMNameList.add(middlename);
                customerFNameList.add(firstname);
                destinationIDList.add(destinationid);
                customerMobileList.add(mobile_number);
                customerEmailList.add(email);
            }
            
            rst.close();
            pstmt.close();
            conn.close();
            
            System.out.println("Adding successful");
            return 1;
           
            } catch (SQLException e) {
           System.out.println(e.getMessage());
           return 0;
       }
         
    }
    
    public int fetch_customer(int customerId) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            String query = "SELECT * FROM Customer WHERE customerid = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, customerId);

            ResultSet resultSet = pstmt.executeQuery();

            if (resultSet.next()) {
                customerid = resultSet.getInt("customerid");
                lastname = resultSet.getString("lastname");
                middlename = resultSet.getString("middlename");
                firstname = resultSet.getString("firstname");
                destinationid = resultSet.getInt("destinationid");
                mobile_number = resultSet.getInt("mobile_number");
                email = resultSet.getString("email");

                return 1;
            }
            pstmt.executeUpdate();

            pstmt.close();
            conn.close();
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return 0; 
    }
    
    public boolean doesCustomerExist(int customerId) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            String query = "SELECT COUNT(*) AS count FROM Customer WHERE customerid = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, customerId);

            ResultSet resultSet = pstmt.executeQuery();

            if (resultSet.next()) {
                int count = resultSet.getInt("count");
                return count > 0; 
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return false;
    }
    
        public int delete_customer(int customerId) {
    try {
        Connection conn;
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
        System.out.println("Connection Successful");

        String deleteQuery = "DELETE FROM Customer WHERE customerid = ?";
        PreparedStatement pstmt = conn.prepareStatement(deleteQuery);
        pstmt.setInt(1, customerId);

        int rowsAffected = pstmt.executeUpdate();

        pstmt.close();
        conn.close();

        if (rowsAffected > 0) {
            System.out.println("Deletion successful");
            return 1;
        } else {
            System.out.println("No record found with Customer ID: " + customerId);
            return 0;
        }
    } catch (SQLException e) {
        System.out.println(e.getMessage());
        return 0;
    }
}
    
}
