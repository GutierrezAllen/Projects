/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Customer;

import java.sql.*;
import java.util.*;


public class Customer_l {
    
    public int customerid;
    public String firstname;
    public String middlename;
    public String lastname;
    public int mobile_number;
    public String email;
    public int destinationid;   
    public String tour_destination;

    public ArrayList<Integer> customerIdList = new ArrayList<> ();
    public ArrayList<String> customerFNameList = new ArrayList<> ();
    public ArrayList<String> customerMNameList = new ArrayList<> ();
    public ArrayList<String> customerLNameList = new ArrayList<> ();
    public ArrayList<Integer> customerMobileList = new ArrayList<> ();
    public ArrayList<String> customerEmailList = new ArrayList<> ();
    
    public ArrayList<Integer> destinationIDList = new ArrayList<> ();

    public Customer_l() {}
        
    public Set<Integer> display_customerid() {
        Set<Integer> uniqueCustomerIds = new HashSet<>();

        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT customerid FROM Customer");
            ResultSet rst = pstmt.executeQuery();

            uniqueCustomerIds.clear();

            while (rst.next()) {
                int customerid = rst.getInt("customerid");
                uniqueCustomerIds.add(customerid);
            }

            pstmt.close();
            conn.close();

            System.out.println("Adding successful");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return uniqueCustomerIds;
    }

    public Set<Integer> display_destinationid() {
        Set<Integer> uniqueDestinationIds = new HashSet<>();

        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT destinationid FROM Customer");
            ResultSet rst = pstmt.executeQuery();

            uniqueDestinationIds.clear();

            while (rst.next()) {
                int destinationid = rst.getInt("destinationid");
                uniqueDestinationIds.add(destinationid);
            }

            pstmt.close();
            conn.close();

            System.out.println("Adding successful");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return uniqueDestinationIds;
    }
    
    public Set<String> display_lastnames() {
        Set<String> uniqueLastNames = new HashSet<>();

        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT lastname FROM Customer");
            ResultSet rst = pstmt.executeQuery();

            uniqueLastNames.clear();

            while (rst.next()) {
                String lastname = rst.getString("lastname");
                uniqueLastNames.add(lastname);
            }

            pstmt.close();
            conn.close();

            System.out.println("Adding successful");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return uniqueLastNames;
    }

    public Set<String> display_middlenames() {
        Set<String> uniqueMiddleNames = new HashSet<>();

        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT middlename FROM Customer");
            ResultSet rst = pstmt.executeQuery();

            uniqueMiddleNames.clear();

            while (rst.next()) {
                String middlename = rst.getString("middlename");
                uniqueMiddleNames.add(middlename);
            }

            pstmt.close();
            conn.close();

            System.out.println("Adding successful");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return uniqueMiddleNames;
    }

    public Set<String> display_firstnames() {
        Set<String> uniqueFirstNames = new HashSet<>();

        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT firstname FROM Customer");
            ResultSet rst = pstmt.executeQuery();

            uniqueFirstNames.clear();

            while (rst.next()) {
                String firstname = rst.getString("firstname");
                uniqueFirstNames.add(firstname);
            }

            pstmt.close();
            conn.close();

            System.out.println("Adding successful");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return uniqueFirstNames;
    }

    public List<Customer_l> list_customers(int customerId, String lastName, String middleName, String firstName, int destinationId) {
        List<Customer_l> matchingCustomers = new ArrayList<>();

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            StringBuilder queryBuilder = new StringBuilder("SELECT * FROM TourTransportationdb.Customer WHERE");

            boolean conditionsAdded = false;

            if (customerId > 0) {
                queryBuilder.append(" customerid = ?");
                conditionsAdded = true;
            }


            if (lastName != null && !lastName.isEmpty() && !lastName.equals("none")) {
                if (conditionsAdded) {
                    queryBuilder.append(" AND");
                }
                queryBuilder.append(" lastname = ?");
                conditionsAdded = true;
            }

            if (middleName != null && !middleName.isEmpty() && !middleName.equals("none")) {
                if (conditionsAdded) {
                    queryBuilder.append(" AND");
                }
                queryBuilder.append(" middlename = ?");
                conditionsAdded = true;
            }

            if (firstName != null && !firstName.isEmpty() && !firstName.equals("none")) {
                if (conditionsAdded) {
                    queryBuilder.append(" AND");
                }
                queryBuilder.append(" firstname = ?");
                conditionsAdded = true;
            }
             if (destinationId > 0) {
                if (conditionsAdded) {
                    queryBuilder.append(" AND");
                }
                queryBuilder.append(" destinationid = ?");
                conditionsAdded = true;
            }

            System.out.println("Generated SQL Query: " + queryBuilder.toString());

            PreparedStatement pstmt = conn.prepareStatement(queryBuilder.toString());

        int parameterIndex = 1;
        if (customerId > 0) {
            pstmt.setInt(parameterIndex++, customerId);
        }
                

        if (lastName != null && !lastName.isEmpty() && !lastName.equals("none")) {
            pstmt.setString(parameterIndex++, lastName);
        }

        if (middleName != null && !middleName.isEmpty() && !middleName.equals("none")) {
            pstmt.setString(parameterIndex++, middleName);
        }

        if (firstName != null && !firstName.isEmpty() && !firstName.equals("none")) {
            pstmt.setString(parameterIndex++, firstName);
        }
        
        if (destinationId > 0) {
            pstmt.setInt(parameterIndex++, destinationId);
        }

            System.out.println("Filled SQL Statement: " + pstmt.toString());
                    
            ResultSet resultSet = pstmt.executeQuery();

            while (resultSet.next()) {
                Customer_l details = new Customer_l();
                details.customerid = resultSet.getInt("customerid");
                details.lastname = resultSet.getString("lastname");
                details.middlename = resultSet.getString("middlename");
                details.firstname = resultSet.getString("firstname");
                details.destinationid = resultSet.getInt("destinationid");
                details.mobile_number = resultSet.getInt("mobile_number");
                details.email = resultSet.getString("email");

                matchingCustomers.add(details);
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return matchingCustomers;
    }
    
    public int choose_destination(){
         try {
             Connection conn;         
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
           System.out.println("Connection Successful");
           
           PreparedStatement pstmtDest = conn.prepareStatement("SELECT destinationid, tour_destination FROM TourDestinations WHERE status = 'A';");
           ResultSet rst = pstmtDest.executeQuery();
           
           destinationIDList.clear();
           
           
             while(rst.next()){
            
                destinationid = rst.getInt("destinationid");
                tour_destination = rst.getString("tour_destination");
                
                destinationIDList.add(destinationid);
                
                
             }
    
            rst.close();
            pstmtDest.close();
            conn.close();
            
            System.out.println("Adding successful");
            return 1;
           
            } catch (SQLException e) {
           System.out.println(e.getMessage());
           return 0;
       }
         
    }
}

