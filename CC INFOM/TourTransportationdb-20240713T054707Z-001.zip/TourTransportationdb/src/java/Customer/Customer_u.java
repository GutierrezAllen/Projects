/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Customer;

/**
 *
 * @author ccslearner
 */
import java.sql.*;
import java.util.*;
import java.util.ArrayList;

public class Customer_u {
    
    public int customerid;
    public String firstname;
    public String middlename;
    public String lastname;
    public int mobile_number;
    public String email;
    public int destinationid;
    public String tour_destination;
    public String tour_description;
    public String status;
    public int tour_cost;      
    
    public ArrayList<Integer> customerIdList = new ArrayList<> ();
    public ArrayList<String> customerFNameList = new ArrayList<> ();
    public ArrayList<String> customerMNameList = new ArrayList<> ();
    public ArrayList<String> customerLNameList = new ArrayList<> ();
    public ArrayList<Integer> customerMobileList = new ArrayList<> ();
    public ArrayList<String> customerEmailList = new ArrayList<> ();
    
    public ArrayList<Integer> destinationIDList = new ArrayList<> ();
    public ArrayList<String> destinationList = new ArrayList<> ();
    public ArrayList<String> destinationDescList = new ArrayList<> ();
    public ArrayList<Integer> destinationCostList = new ArrayList<> ();
    public ArrayList<String> destinationStatusList = new ArrayList<> ();
    
    public Customer_u() {}    
        
    public int update_customer(int customerId, String lastName, String middleName, String firstName, int destinationId, int mobileNumber, String email) {
        
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            String updateQuery = "UPDATE Customer SET lastname=?, middlename=?, firstname=?, destinationid=?, mobile_number=?, email=? WHERE customerid=?";

            PreparedStatement pstmt = conn.prepareStatement(updateQuery);
            
   
            pstmt.setString(1, lastName);
            pstmt.setString(2, middleName);
            pstmt.setString(3, firstName);
            pstmt.setInt(4, destinationId);
            pstmt.setInt(5, mobileNumber);
            pstmt.setString(6, email);
            pstmt.setInt(7, customerId);

            int rowsAffected = pstmt.executeUpdate();

            pstmt.close();
            conn.close();

            if (rowsAffected > 0) {
                System.out.println("Update successful");
                return 1;
            } else {
                System.out.println("No record found with Customer ID: " + customerId);
                return 0;
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
        
    public int fetch_customer(int customerId) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            String query = "SELECT * FROM Customer WHERE customerid = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, customerId);

            ResultSet resultSet = pstmt.executeQuery();

            if (resultSet.next()) {
                customerid = resultSet.getInt("customerid");
                lastname = resultSet.getString("lastname");
                middlename = resultSet.getString("middlename");
                firstname = resultSet.getString("firstname");
                destinationid = resultSet.getInt("destinationid");
                mobile_number = resultSet.getInt("mobile_number");
                email = resultSet.getString("email");

                return 1;
            }
            pstmt.executeUpdate();

            pstmt.close();
            conn.close();
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return 0; 
    }
    
    public int display_customer(){
         try {
             Connection conn;
         
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
           System.out.println("Connection Successful");
           
           PreparedStatement pstmt = conn.prepareStatement("SELECT customerid, lastname, middlename, firstname, destinationid, mobile_number, email FROM Customer;");
           ResultSet rst = pstmt.executeQuery();
           
           customerIdList.clear();
           customerLNameList.clear();
           customerMNameList.clear();
           customerFNameList.clear();
           destinationIDList.clear();
           customerMobileList.clear();
           customerEmailList.clear();
           
            while(rst.next()){
                customerid = rst.getInt("customerid");
                lastname = rst.getString("lastname");
                middlename = rst.getString("middlename");
                firstname = rst.getString("firstname");
                destinationid = rst.getInt("destinationid");
                mobile_number = rst.getInt("mobile_number");
                email = rst.getString("email");
                
                customerIdList.add(customerid);
                customerLNameList.add(lastname);
                customerMNameList.add(middlename);
                customerFNameList.add(firstname);
                destinationIDList.add(destinationid);
                customerMobileList.add(mobile_number);
                customerEmailList.add(email);
            }
            
            rst.close();
            pstmt.close();
            conn.close();
            
            System.out.println("Adding successful");
            return 1;
           
            } catch (SQLException e) {
           System.out.println(e.getMessage());
           return 0;
       }
         
    }
    
    public int choose_destination(){
         try {
             Connection conn;         
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
           System.out.println("Connection Successful");
           
           PreparedStatement pstmtDest = conn.prepareStatement("SELECT destinationid, tour_destination, tour_description, tour_cost FROM TourDestinations WHERE status = 'A';");
           ResultSet rst = pstmtDest.executeQuery();
           
           destinationIDList.clear();
           destinationList.clear();
           destinationDescList.clear();
           destinationCostList.clear();
           destinationStatusList.clear(); 
           
             while(rst.next()){
            
                destinationid = rst.getInt("destinationid");
                tour_destination = rst.getString("tour_destination");
                tour_description = rst.getString("tour_description");
                status = "A";
                tour_cost = rst.getInt("tour_cost");
                
                destinationIDList.add(destinationid);
                destinationList.add(tour_destination);
                destinationDescList.add(tour_description);
                destinationCostList.add(tour_cost);
                destinationStatusList.add(status); 
                
                
             }
    
            rst.close();
            pstmtDest.close();
            conn.close();
            
            System.out.println("Adding successful");
            return 1;
           
            } catch (SQLException e) {
           System.out.println(e.getMessage());
           return 0;
       }
         
    }
    
    public boolean isValidCustomerId(int customerId) {
        String driverIdString = String.valueOf(customerId);
        return driverIdString.length() == 4 && driverIdString.startsWith("1");
    }
    
    public boolean isValidName(String name) {
        for (char c : name.toCharArray()) {
            if (Character.isDigit(c)) {
                return false; 
            }
        }
        return true; 
    }

    public boolean isValidLastName(String lastName) {
        return isValidName(lastName);
    }

    public boolean isValidMiddleName(String middleName) {
        return isValidName(middleName);
    }

    public boolean isValidFirstName(String firstName) {
        return isValidName(firstName);
    }
    
    public int getCustomerid() {
        return customerid;
    }
        
    public int getDestinationid() {
        return destinationid;
    }

    public String getLastname() {
        return lastname;
    }

    public String getMiddlename() {
        return middlename;
    }

    public String getFirstname() {
        return firstname;
    }

    public int getMobile_number() {
        return mobile_number;
    }

    public String getEmail() {
        return email;
    }
}
