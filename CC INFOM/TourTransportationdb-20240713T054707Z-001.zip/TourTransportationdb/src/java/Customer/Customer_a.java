package Customer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ccslearner
 */
import java.util.*;
import java.sql.*;
import java.util.ArrayList;

public class Customer_a {
    
    public int customerid;
    public String firstname;
    public String middlename;
    public String lastname;
    public int mobile_number;
    public String email;
    public int destinationid;
    public String tour_destination;
    public String tour_description;
    public String status;
    public int tour_cost;
    
    public ArrayList<Integer> customerIdList = new ArrayList<> ();
    public ArrayList<String> customerFNameList = new ArrayList<> ();
    public ArrayList<String> customerMNameList = new ArrayList<> ();
    public ArrayList<String> customerLNameList = new ArrayList<> ();
    public ArrayList<Integer> customerMobileList = new ArrayList<> ();
    public ArrayList<String> customerEmailList = new ArrayList<> ();
    
    public ArrayList<Integer> destinationIDList = new ArrayList<> ();
    public ArrayList<String> destinationList = new ArrayList<> ();
    public ArrayList<String> destinationDescList = new ArrayList<> ();
    public ArrayList<Integer> destinationCostList = new ArrayList<> ();
    public ArrayList<String> destinationStatusList = new ArrayList<> ();
    
    public Customer_a() {}
    
    public int register_customer() {
        try{
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmtMaxId = conn.prepareStatement("SELECT MAX(customerid) + 1 AS newCustomerID FROM Customer;");
            ResultSet rst = pstmtMaxId.executeQuery();
            
            while (rst.next()) {
               customerid = rst.getInt("newCustomerID");
           }    
            
            String insertQuery = "INSERT INTO Customer (customerid, firstname, middlename, lastname, destinationid, mobile_number, email) VALUE (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(insertQuery);
            
            pstmt.setInt(1,customerid); 
            pstmt.setString(2,firstname);
            pstmt.setString(3,middlename);
            pstmt.setString(4,lastname);
            pstmt.setInt(5,destinationid);
            pstmt.setInt(6,mobile_number);
            pstmt.setString(7,email);
            
            pstmt.executeUpdate();
            
            rst.close();
            pstmt.close();
            conn.close();
            
            System.out.println("Adding Successful");
            return 1;
            
        } catch (Exception e){
            System.out.println(e.getMessage());
            return 0;
        }
        
    }
    
    
    public int choose_destination(){
         try {
             Connection conn;         
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
           System.out.println("Connection Successful");
           
           PreparedStatement pstmtDest = conn.prepareStatement("SELECT destinationid, tour_destination, tour_description, tour_cost FROM TourDestinations WHERE status = 'A';");
           ResultSet rst = pstmtDest.executeQuery();
           
           destinationIDList.clear();
           destinationList.clear();
           destinationDescList.clear();
           destinationCostList.clear();
           destinationStatusList.clear(); 
           
             while(rst.next()){
            
                destinationid = rst.getInt("destinationid");
                tour_destination = rst.getString("tour_destination");
                tour_description = rst.getString("tour_description");
                status = "A";
                tour_cost = rst.getInt("tour_cost");
                
                destinationIDList.add(destinationid);
                destinationList.add(tour_destination);
                destinationDescList.add(tour_description);
                destinationCostList.add(tour_cost);
                destinationStatusList.add(status); 
                
                
             }
    
            rst.close();
            pstmtDest.close();
            conn.close();
            
            System.out.println("Adding successful");
            return 1;
           
            } catch (SQLException e) {
           System.out.println(e.getMessage());
           return 0;
       }
         
    }
    
    public boolean isValidName(String name) {
        for (char c : name.toCharArray()) {
            if (Character.isDigit(c)) {
                return false; 
            }
        }
        return true; 
    }

    public boolean isValidLastName(String lastName) {
        return isValidName(lastName);
    }

    public boolean isValidMiddleName(String middleName) {
        return isValidName(middleName);
    }

    public boolean isValidFirstName(String firstName) {
        return isValidName(firstName);
    }
    
    
    public static void main(String args[]){
        
         Customer_a C = new Customer_a();
            
         C.register_customer();
        
    }
}
