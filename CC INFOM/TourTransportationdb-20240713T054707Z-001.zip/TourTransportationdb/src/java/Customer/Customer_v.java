/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Customer;

/**
 *
 * @author ccslearner
 */
import java.sql.*;
import java.util.*;
import java.util.ArrayList;

public class Customer_v {

    public int customerid;
    public String firstname;
    public String middlename;
    public String lastname;
    public int mobile_number;
    public String email;
    public int destinationid;   
    public String tour_destination;

    public ArrayList<Integer> customerIdList = new ArrayList<> ();
    public ArrayList<String> customerFNameList = new ArrayList<> ();
    public ArrayList<String> customerMNameList = new ArrayList<> ();
    public ArrayList<String> customerLNameList = new ArrayList<> ();
    public ArrayList<Integer> customerMobileList = new ArrayList<> ();
    public ArrayList<String> customerEmailList = new ArrayList<> ();
    
    public ArrayList<Integer> destinationIDList = new ArrayList<> ();
    
    public Customer_v() {}

    public List<Customer_v> search_customer(int customerId) {
        List<Customer_v> matchingCustomers = new ArrayList<>();

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            String query = "SELECT * FROM Customer WHERE customerid = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);

            pstmt.setInt(1, customerId);

            ResultSet resultSet = pstmt.executeQuery();

            while (resultSet.next()) {
                Customer_v details = new Customer_v();
                details.customerid = resultSet.getInt("customerid");
                details.lastname = resultSet.getString("lastname");
                details.middlename = resultSet.getString("middlename");
                details.firstname = resultSet.getString("firstname");
                details.destinationid = resultSet.getInt("destinationid");
                details.mobile_number = resultSet.getInt("mobile_number");
                details.email = resultSet.getString("email");

                matchingCustomers.add(details);
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return matchingCustomers;
    }
    
}

