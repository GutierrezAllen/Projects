/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VehicleCancellation;

import java.sql.*;
import java.util.*;

/**
 *
 * @author ccslearner
 */
public class vehicle_cancellation {
    
    public enum VehicleType {
        C,
        SUV,
        V,
        B
    }
    
    public enum isApproved {
        Y,
        N
    }
    
    public int vehicleid;
    public String plate_number;
    public int driverid;
    public VehicleType vehicle_type;
    public String reason;
    public isApproved isapproved;
    
    public int destinationid;
    public int scheduleid;
    public int start_date;
    
    public ArrayList<Integer> vehicleidList = new ArrayList<> ();
    public ArrayList<String> plate_numberList = new ArrayList<> ();
    public ArrayList<Integer> driveridList = new ArrayList<> ();
    public ArrayList<VehicleType> vehicle_typeList = new ArrayList<> ();
    public ArrayList<String> reasonList = new ArrayList<> ();
    public ArrayList<isApproved> approvedList = new ArrayList<> ();
    public ArrayList<Integer> destinationIDList = new ArrayList<> ();
    public ArrayList<Integer> scheduleList = new ArrayList<> ();
    public ArrayList<Integer> dateList = new ArrayList<> ();
    
    public vehicle_cancellation() {}
    
    public int register_cancellation() {
        try{
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmtDest = conn.prepareStatement("SELECT * FROM VehicleCancellation;");
            ResultSet rst = pstmtDest.executeQuery();
            
            String insertQuery = "INSERT INTO VehicleCancellation (vehicleid, plate_number, driverid, vehicle_type, reason, isapproved, scheduleid) VALUE (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(insertQuery);
            
            pstmt.setInt(1,vehicleid); 
            pstmt.setString(2,plate_number);
            pstmt.setInt(3,driverid);
            pstmt.setString(4,vehicle_type.name());
            pstmt.setString(5,reason);
            pstmt.setString(6,isapproved.name());
            pstmt.setInt(7,scheduleid);
            
            pstmt.executeUpdate();
            
            rst.close();
            pstmt.close();
            conn.close();
            
            System.out.println("Adding Successful");
            return 1;
            
        } catch (Exception e){
            System.out.println(e.getMessage());
            return 0;
        }
        
    }
    
       public int fetch_vehicle(int vehicleId) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            String query = "SELECT vehicle_type FROM Transportation WHERE vehicleid = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, vehicleId);

            ResultSet resultSet = pstmt.executeQuery();

            if (resultSet.next()) {
                vehicleid = resultSet.getInt("vehicleid");
                plate_number = resultSet.getString("plate_number");
                vehicle_type = VehicleType.valueOf(resultSet.getString("vehicle_type"));
                driverid = resultSet.getInt("driverid");
                
                return 1;
            }
            pstmt.executeUpdate();

            pstmt.close();
            conn.close();
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return 0; 
    }
    
        public int display_transportation(){
         try {
             Connection conn;
         
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
           System.out.println("Connection Successful");
           
           PreparedStatement pstmt = conn.prepareStatement("SELECT vehicleid, plate_number, driverid, vehicle_type FROM Transportation;");
           ResultSet rst = pstmt.executeQuery();
           
           vehicleidList.clear();
           plate_numberList.clear();
           driveridList.clear();
           vehicle_typeList.clear();
           
            while(rst.next()){
                vehicleid = rst.getInt("vehicleid");
                plate_number = rst.getString("plate_number"); 
                driverid = rst.getInt("driverid");
                vehicle_type = VehicleType.valueOf(rst.getString("vehicle_type"));
                
                vehicleidList.add(vehicleid);
                plate_numberList.add(plate_number);
                driveridList.add(driverid);
                vehicle_typeList.add(vehicle_type);
                
            }
            
            rst.close();
            pstmt.close();
            conn.close();
            
            System.out.println("Adding successful");
            return 1;
           
            } catch (SQLException e) {
           System.out.println(e.getMessage());
           return 0;
       }
         
    }
 
      public int add_cancellation() {
       try {
           Connection conn;
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
           System.out.println("Connection Successful");

           PreparedStatement pstmtsched = conn.prepareStatement("SELECT scheduleid FROM SchedulingInformation WHERE vehicleid=?");
           
           pstmtsched.setInt(1, vehicleid);
           ResultSet rst = pstmtsched.executeQuery();
           while (rst.next()) {
               scheduleid = rst.getInt("scheduleid");
           }
           
           pstmtsched.executeUpdate();

           String insertQuery = "INSERT INTO VehicleCancellation (vehicleid, plate_number, vehicle_type, driverid, reason, isapproved, scheduleid) VALUES (?, ?, ?, ?, ?, ?, ?)";
           PreparedStatement pstmt = conn.prepareStatement(insertQuery);

           pstmt.setInt(1, vehicleid);
           pstmt.setString(2, plate_number);
           pstmt.setString(3, vehicle_type.name());  
           pstmt.setInt(4, driverid);
           pstmt.setString(5, reason);
           pstmt.setString(6, isapproved.name());
           pstmt.setInt(7, scheduleid);

           pstmt.executeUpdate();

           pstmt.close();
           conn.close();

           System.out.println("Adding successful");
           return 1;

       } catch (SQLException e) {
           System.out.println(e.getMessage());
           return 0;
       }
   }  
      
public Set<String> display_reason() {
        Set<String> uniqueReasons = new HashSet<>();

        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT reason FROM VehicleCancellation");
            ResultSet rst = pstmt.executeQuery();

            uniqueReasons.clear();

            while (rst.next()) {
                int vehicleid = rst.getInt("reason");
                uniqueReasons.add(reason);
            }

            pstmt.close();
            conn.close();

            System.out.println("Adding successful");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return uniqueReasons;
    }

   public int choose_dateOrDestination(){
         try {
             Connection conn;         
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
           System.out.println("Connection Successful");
           
           PreparedStatement pstmtD = conn.prepareStatement("SELECT scheduleid, start_date, destinationid FROM SchedulingInformation;");
           ResultSet rst = pstmtD.executeQuery();
           
           scheduleList.clear();
           dateList.clear();
           destinationIDList.clear();
 
           
             while(rst.next()){
            
                destinationid = rst.getInt("destinationid");
                scheduleid = rst.getInt("scheduleid");
                start_date = rst.getInt("start_date");
                
                destinationIDList.add(destinationid); 
                scheduleList.add(scheduleid); 
                dateList.add(start_date);
                
             }
    
            rst.close();
            pstmtD.close();
            conn.close();
            
            System.out.println("Adding successful");
            return 1;
           
            } catch (SQLException e) {
           System.out.println(e.getMessage());
           return 0;
       }
         
    }
    
    public Set<Integer> display_destination() {
        Set<Integer> uniqueDestinations = new HashSet<>();

        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT destinationid FROM SchedulingInformation");
            ResultSet rst = pstmt.executeQuery();

           
            
            uniqueDestinations.clear();

            while (rst.next()) {
                int destinationid = rst.getInt("destinationid");
                uniqueDestinations.add(destinationid);
            }

            pstmt.close();
            conn.close();

            System.out.println("Adding successful");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return uniqueDestinations;
    }

    
    public List<vehicle_cancellation> display_report(int vehicleId, VehicleType vehicleType, int driverId, String reason, isApproved approvedStatus, int scheduleId) {
        List<vehicle_cancellation> matchingRecords = new ArrayList<>();

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/TourTransportationdb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            StringBuilder queryBuilder = new StringBuilder("SELECT * FROM TourTransportationdb.VehicleCancellation WHERE");

            boolean conditionsAdded = false;

            if (reason != null) {
                queryBuilder.append(" reason = ?");
                conditionsAdded = true;
            }


            System.out.println("Generated SQL Query: " + queryBuilder.toString());

            PreparedStatement pstmt = conn.prepareStatement(queryBuilder.toString());

        int parameterIndex = 1;
        if (reason != null) {
            pstmt.setInt(parameterIndex++, vehicleId);
        }
                
            System.out.println("Filled SQL Statement: " + pstmt.toString());
                    
            ResultSet resultSet = pstmt.executeQuery();

            while (resultSet.next()) {
                vehicle_cancellation details = new vehicle_cancellation();
                details.vehicleid = resultSet.getInt("vehicleid");
                details.plate_number = resultSet.getString("plate_number");
                details.vehicle_type = VehicleType.valueOf(resultSet.getString("vehicle_type"));
                details.driverid = resultSet.getInt("driverid");
                details.reason = resultSet.getString("reason");
                details.isapproved = isApproved.valueOf(resultSet.getString("isapproved"));
                details.scheduleid = resultSet.getInt("scheduleid");

                matchingRecords.add(details);
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return matchingRecords;
    }
}
     
