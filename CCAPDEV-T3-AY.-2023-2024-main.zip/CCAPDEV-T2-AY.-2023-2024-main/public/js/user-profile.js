function editBtn(){
    window.location.href = "/edit-profile"
}