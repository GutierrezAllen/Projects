/* This file contains implementations of sorting algorithms.
 * You are NOT allowed to modify any of the given method headers.
 */

public class SortingAlgorithms {

    /*
     * You may define additional helper functions here if you need to.
     * Make sure the helper functions have the private access modifier, as
     * they will only be used in this class.
     */

    public void insertionSort(Record[] arr, int n) {
        Record key = new Record("NULL",0000);
        //FCquickSort.addFC(1);
        
        for(int i = 0; i < n; i++){
            key = arr[i];
            //FCquickSort.addFC(1);

            int j = i-1;
            //FCquickSort.addFC(1);

            while(j >= 0 && arr[j].getIdNumber()>key.getIdNumber()){
                arr[j+1] = arr[j];
                //FCquickSort.addFC(1);
                j = j -1;
                //FCquickSort.addFC(1);
            }
            arr[j+1] = key;
            //FCquickSort.addFC(1);
        }
        //FCquickSort.addFC(1);
    }

    public void selectionSort(Record[] arr, int n) {
        for(int i = 0; i < n-1 ; i++){
            //FCquickSort.addFC(1);

            int minIndex = i;
            //FCquickSort.addFC(1);

            for(int j = i+1; j<n; j++){
                //FCquickSort.addFC(1);

                if(arr[j].getIdNumber() < arr[minIndex].getIdNumber()){
                    minIndex = j;
                    //FCquickSort.addFC(1);
                }
            }

            swap(arr,minIndex,i);
            //FCquickSort.addFC(4);
        }
        //FCquickSort.addFC(1);
    }

    public void mergeSort (Record[] arr, int l, int r) {
        if (l < r) {
            int m = l + (r - l) / 2;
            //FCquickSort.addFC(1);

            mergeSort(arr, l, m);                   //recursive function that calls itself to sort out elements in a array
            //FCquickSort.addFC(1);
            
            mergeSort(arr, m + 1, r);               
            //FCquickSort.addFC(1);

            merge(arr, l, m, r);                    //calls out merge() function to merge both arrays
            //FCquickSort.addFC(1);
        }
    }

    private void merge(Record[] arr, int l, int m, int r) {      
        int subArrInd1 = m - l + 1;                    //index instantiation for temp 2 sub arrays
        int subArrInd2 = r - m;
        //FCquickSort.addFC(2);

        Record leftSide[] = new Record[subArrInd1];    //instantiate the two sub arrays
        Record rightSide[] = new Record[subArrInd2];
        //FCquickSort.addFC(2);

        for (int i = 0; i < leftSide.length; ++i) {
            //FCquickSort.addFC(2);
            leftSide[i] = arr[l + i];               //assigns values the left side array
        }
        //FCquickSort.addFC(1);
            
        for (int j = 0; j < rightSide.length; ++j){
            //FCquickSort.addFC(2);
            rightSide[j] = arr[m + 1 + j];          //assigns values the right side array
        }
        //FCquickSort.addFC(2);
            

        int i = 0, j = 0;       //instantiate indices for the first and second sub arrays
        int k = l;              //k indicates the index of a merged subarray array
        //FCquickSort.addFC(2);
        
        while (i < subArrInd1 && j < subArrInd2) {
            //FCquickSort.addFC(1);

            if (compare(leftSide[i], rightSide[j]) <= 0) { // Ayus na ba?
                arr[k] = leftSide[i];
                i++;
                //FCquickSort.addFC(2);
            }                   //sort 2 sub arrays into one array for one time
            else {
                arr[k] = rightSide[j];
                j++;
                //FCquickSort.addFC(2);
            }
            //FCquickSort.addFC(1);
            k++;
            //FCquickSort.addFC(1);
        }
        //FCquickSort.addFC(1);

        while (i < subArrInd1) {
            //FCquickSort.addFC(1);
            arr[k] = leftSide[i];       //input remaining elements of leftSide[] subarray onto merged array
            i++;
            k++;
            //freqCounter += 3;
        }

        while (i < subArrInd2) {
            //FCquickSort.addFC(1);
            arr[k] = rightSide[j];      //input remaining elements of rightSide[] subarray onto merged array
            j++;
            k++;
            //FCquickSort.addFC(3);
        }
    }

    private int compare(Record leftSide, Record rightSide) {
        return Integer.compare(leftSide.getIdNumber(), rightSide.getIdNumber());    //Helper method for comparing
    }

    /*
    Main method where it recursively calls itself into smaller partitions around a
    pivot element
     */
    public void quickSort(Record[] arr, int lowerIndex, int higherIndex) {
        while (lowerIndex < higherIndex) {
            //FCquickSort.addFC(1);

            int pivotIndex = partitionArrange(arr, lowerIndex, higherIndex); // gets the index of the pivot
            //FCquickSort.addFC(1);

            if (pivotIndex - lowerIndex < higherIndex - pivotIndex) {
                quickSort(arr, lowerIndex, pivotIndex - 1); // sort the left subarray
                lowerIndex = pivotIndex + 1; // update the lower index for the next iteration
            } else {
                quickSort(arr, pivotIndex + 1, higherIndex); // sort the right subarray
                higherIndex = pivotIndex - 1; // update the higher index for the next iteration
            }
            //FCquickSort.addFC(2);
            }
        //FCquickSort.addFC(1);
    }

    private int partitionArrange(Record[] arr, int lowerIndex, int higherIndex) {
        // Choose a pivot element from the middle index
        int pivotIndex = lowerIndex + (higherIndex - lowerIndex) / 2;
        Record pivotElement = arr[pivotIndex];

        // Move the pivot element to the end
        swap(arr, pivotIndex, higherIndex);
        //FCquickSort.addFC(3);

        int i = lowerIndex;
        //FCquickSort.addFC(1);

        for (int j = lowerIndex; j < higherIndex; j++) {
        //FCquickSort.addFC(1);
            if (arr[j].getIdNumber() < pivotElement.getIdNumber()) {
                swap(arr, i, j);
                i++;
                //FCquickSort.addFC(2);
        }
        //FCquickSort.addFC(1);
    }

    swap(arr, i, higherIndex);
    //FCquickSort.addFC(4);

    return i;
}

    private void swap(Record[] arr, int j,int i){
        Record temp = new Record("NULL", 0000);
        temp = arr[j];
        arr[j] = arr[i];
        arr[i] = temp;
    }
}

