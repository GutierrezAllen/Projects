public class FreqCount {
    double freqCounter;

    public FreqCount () {
        this.freqCounter = 0;           //instantiation
    }
    public void addFC(double FC) {
        this.freqCounter += FC;         //updater
    }
    public double getFC() {
        return this.freqCounter;        //to pass the values to other files
    }
}