
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // TODO: Use this method to run your experiments.
        FileReader fileReader = new FileReader();
        Record[] records = fileReader.readFile("C:\\Users\\Ryu Kisen\\Documents\\1. DLSU\\CCDSALG\\MCO1\\java\\source-CCDSALG-MCO1-S17-35\\data\\random100.txt"); // File path insert here

        // Display old records
        //System.out.println("Unsorted: ");
        //for (Record record : records) {
        //    System.out.println(record.getIdNumber() + " " + record.getName());
        //}

        SortingAlgorithms sortingAlgorithms = new SortingAlgorithms();

        // Choose a sorting algorithm
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nChoose a sorting algorithm:");
        System.out.println("1. Insertion Sort");
        System.out.println("2. Selection Sort");
        System.out.println("3. Merge Sort");
        System.out.println("4. Quick Sort");
        int choice = scanner.nextInt();

        scanner.close();
        // Perform the selected sorting algorithm
        // FreqCount FC = new FreqCount();
        long startTime = System.currentTimeMillis();
        switch (choice) {
            case 1:                
                sortingAlgorithms.insertionSort(records, records.length); //Insertion Sort
                break;
            case 2:
                sortingAlgorithms.selectionSort(records, records.length); //Selection Sort
                break;
            case 3:
                sortingAlgorithms.mergeSort(records, 0, records.length - 1); //Merge Sort
                break;
            case 4:
                sortingAlgorithms.quickSort(records, 0, records.length - 1); //Quick Sort
                break;
            default:
                System.out.println("Invalid choice. Sorting aborted.");
                return;
        }
        long endTime = System.currentTimeMillis();
        long executionTime = endTime - startTime;
        System.out.println("\nResult: ");
        for (Record record : records) {
            System.out.println(record.getIdNumber() + " " + record.getName());
        }
        //System.out.println("Frequency Counter:\t" + FC.getFC());     //displays the frequency count of the sorting algorithm
        
        System.out.println("Execution Time:\t" + executionTime);
    }
}
