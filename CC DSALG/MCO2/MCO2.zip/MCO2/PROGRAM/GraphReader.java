import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GraphReader {

    public static List<List<Integer>> readGraphFromFile(String filePath) throws IOException {
        List<List<Integer>> graph = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) { //bufferedreader for better reading of large text files
            String line = br.readLine(); // reads each line
            int n = Integer.parseInt(line.split(" ")[0]); // for the space in between the two ID numbers

            for (int i = 0; i < n; i++) {
                graph.add(new ArrayList<>());
            }

            while ((line = br.readLine()) != null) { // reads each line until the end
                String[] friendship = line.split(" ");
                int a = Integer.parseInt(friendship[0]);
                int b = Integer.parseInt(friendship[1]);
                graph.get(a).add(b);
            }
        }

        return graph;
    }
}
