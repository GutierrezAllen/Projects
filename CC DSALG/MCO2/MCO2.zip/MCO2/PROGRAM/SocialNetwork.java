
import java.util.List;

public class SocialNetwork {

    private List<List<Integer>> graph;

    public SocialNetwork(List<List<Integer>> graph) {
        this.graph = graph;
    }

    public List<Integer> getFriendList(int personID) {
        return graph.get(personID);
    }

    public boolean hasConnection(int personID1, int personID2) {
        ConnectionPathFinder pathFinder = new ConnectionPathFinder(graph);
        List<Integer> path = pathFinder.findConnectionPath(personID1, personID2);

        if (!path.isEmpty()) {
            
            printConnectionPath(path,personID1, personID2);
            return true;
        } else {
            System.out.println("Cannot find a connection between " + personID1 + " and " + personID2);
            return false;
        }
    }

    private void printConnectionPath(List<Integer> path, int personID1, int personID2) {
       
        int lastPersonID = path.get(0);
        if (lastPersonID == personID2) {
            System.out.println("There is a connection from " + personID1 + " to " + personID2 + "!");
            System.out.println();
                System.out.print("Path: ");
            for (int i = path.size() - 1; i > 0; i--) {
                int personID = path.get(i);
                System.out.print(personID + " is friends with ");
                int nextPersonID = path.get(i - 1);
                System.out.print(nextPersonID);
                if (i > 1) {
                    System.out.println();
                }
            }
        } else {
            System.out.println("\nNo connection found between person 1 and person " + personID2);
        }
    }
    
}
