import java.util.ArrayList;
import java.util.List;

public class ConnectionPathFinder {

    private List<List<Integer>> graph;
    private boolean[] visited;

    public ConnectionPathFinder(List<List<Integer>> graph) {
        this.graph = graph;
    }

    public List<Integer> findConnectionPath(int personID1, int personID2) {
        visited = new boolean[graph.size()];
        return hasConnectionDFS(personID1, personID2);
    }

    private List<Integer> hasConnectionDFS(int current, int target) {
        if (current == target) {
            List<Integer> path = new ArrayList<>();
            path.add(current);
            return path;
        }
    
        visited[current] = true;
    
        List<Integer> friends = graph.get(current);
        for (int i = 0; i < friends.size(); i++) {
            int friend = friends.get(i);
            if (!visited[friend]) {
                List<Integer> newPath = hasConnectionDFS(friend, target);
                if (newPath != null) {
                    newPath.add(current);
                    return newPath;
                }
            }
        }
    
        // If no connection is found, mark the current node as unvisited and return an empty list.
        visited[current] = false;
        return new ArrayList<>();
    }
    
}
