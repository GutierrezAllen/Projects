import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Input file name: ");
            String fileName = scanner.nextLine();
            String filePath = Paths.get(System.getProperty("user.dir"), fileName).toString();
            File file = new File(filePath);

            if (!file.exists()) {
                System.out.println("Error: The specified file does not exist. Please try again.");
            } else {
                try {
                    List<List<Integer>> graph = GraphReader.readGraphFromFile(filePath);
                    SocialNetwork socialNetwork = new SocialNetwork(graph);
                    System.out.println("Graph loaded!");

                    while (true) {
                        System.out.println("\nMAIN MENU");
                        System.out.println("[1] Get friend list");
                        System.out.println("[2] Get connection");
                        System.out.println("[3] Exit");
                        System.out.print("Enter your choice: ");
                        int choice = scanner.nextInt();

                        if (choice == 1) {
                            System.out.print("\nEnter ID of person: ");
                            int personID = scanner.nextInt();
                            List<Integer> friendList = socialNetwork.getFriendList(personID);
                            System.out.println("Person " + personID + " has " + friendList.size() + " friends!");
                            System.out.println("List of friends: " + friendList);
                        } else if (choice == 2) {
                            System.out.print("\nEnter ID of first person: ");
                            int personID1 = scanner.nextInt();
                            System.out.print("Enter ID of second person: ");
                            int personID2 = scanner.nextInt();
                            boolean hasConnection = socialNetwork.hasConnection(personID1, personID2);

                            if (hasConnection) {

                            } else {
                                System.out.println("Cannot find a connection between " + personID1 + " and " + personID2);
                            }
                        } else if (choice == 3) {
                            scanner.close();
                            System.exit(0);
                        } else {
                            System.out.println("Invalid choice. Please try again.");
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}