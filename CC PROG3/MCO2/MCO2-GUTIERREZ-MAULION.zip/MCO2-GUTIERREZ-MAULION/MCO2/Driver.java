/*
 * @author Allen Gutierrez 12207292
 * @author Ian Maulion 12209979
 * S11 Group 11
 */

public class Driver {
    /**
     * This is the file that runs the entire program.
     * @param args = argument main function
     */
    public static void main(String[] args) {
        Screen CGame = new Screen();

        CGame.gameStart();
        CGame.displayOptions();
    }
}
