package com.example.guigutierrezmaulion;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class GUIDriverController {

    @FXML
    private Stage stage;
    @FXML
    private Scene scene;
    @FXML
    private Parent root;
    
    /**
     * This navigates the user to the main menu scene.
     * @param event = ActionEvent is triggered by the user's action.
     * @throws IOException = If an error occurs while loading "MainMenu.fxml".
     */
    @FXML
    
    public void toMainMenu(ActionEvent event) throws IOException {
       
        //Loads FXML file "MainMenu.fxml" to switch to the corresponding scene.
        Parent root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
        
        //Gets the reference to the current stage from the event source.
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        //Creates a new scene with the loaded UI.
        scene = new Scene(root);
        
        //Sets the scene for the current stage to switch to the "Area1" scene.
        stage.setScene(scene);
        
        //Displays the updated stage.
        stage.show();
    }

}