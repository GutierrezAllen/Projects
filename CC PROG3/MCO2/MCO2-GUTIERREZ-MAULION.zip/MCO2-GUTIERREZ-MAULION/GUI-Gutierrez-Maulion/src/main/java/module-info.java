module com.example.guigutierrezmaulion {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.guigutierrezmaulion to javafx.fxml;
    exports com.example.guigutierrezmaulion;
}