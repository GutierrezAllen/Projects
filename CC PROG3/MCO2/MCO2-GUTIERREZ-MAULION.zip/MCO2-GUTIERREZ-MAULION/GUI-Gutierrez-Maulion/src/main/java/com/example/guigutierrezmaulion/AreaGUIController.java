package com.example.guigutierrezmaulion;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class AreaGUIController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    /**
     * This will bring the user to the Area1 fxml scene.
     * @param event = ActionEvent is triggered by the user's action.
     * @throws IOException = If an error occurs while loading "Area1.fxml".
     */
    public void toArea1(ActionEvent event) throws IOException {
        
        //Loads FXML file "Area1.fxml" to switch to the corresponding scene.
        Parent root = FXMLLoader.load(getClass().getResource("Area1.fxml"));
        
        //Gets the reference to the current stage from the event source.
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        
        //Creates a new scene with the loaded UI.
        scene = new Scene(root);

        //Sets the scene for the current stage to switch to the "Area1" scene.
        stage.setScene(scene);

        //Displays the updated stage.
        stage.show();
    }
    /**
     * This will bring the user to the Area2 fxml scene.
     * @param event = ActionEvent is triggered by the user's action.
     * @throws IOException = If an error occurs while loading "Area2.fxml".
     */
    public void toArea2(ActionEvent event) throws IOException {

        //Loads FXML file "Area1.fxml" to switch to the corresponding scene.
        Parent root = FXMLLoader.load(getClass().getResource("Area2.fxml"));

        //Gets the reference to the current stage from the event source.
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        //Creates a new scene with the loaded UI.
        scene = new Scene(root);

        //Sets the scene for the current stage to switch to the "Area1" scene.
        stage.setScene(scene);

        //Displays the updated stage.
        stage.show();
    }
    public void toArea3(ActionEvent event) throws IOException {

        //Loads FXML file "Area1.fxml" to switch to the corresponding scene.
        Parent root = FXMLLoader.load(getClass().getResource("Area1.fxml"));

        //Gets the reference to the current stage from the event source.
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        //Creates a new scene with the loaded UI.
        scene = new Scene(root);

        //Sets the scene for the current stage to switch to the "Area1" scene.
        stage.setScene(scene);

        //Displays the updated stage.
        stage.show();
    }

    /**
     * This navigates the user back to the main menu scene.
     * @param event = ActionEvent is triggered by the user's action.
     * @throws IOException = If an error occurs while loading "MainMenu.fxml".
     */
    public void toMainMenu(ActionEvent event) throws IOException {
        
        //Loads FXML file "MainMenu.fxml" to switch to the corresponding scene.
        Parent root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
        
        //Gets the reference to the current stage from the event source.
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        
        //Creates a new scene with the loaded UI.
        scene = new Scene(root);
        
        //Sets the scene for the current stage to switch to the "Area1" scene.
        stage.setScene(scene);
        
        //Displays the updated stage.
        stage.show();
    }
}
