package com.example.guigutierrezmaulion;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class AreaGUI extends Application {
    /**
     * 
     * @param stage = Primary stage for the JavaFX application.
     * @throws IOException = If an error occurs while loading the FXML file.
     */
    @Override
    public void start(Stage stage) throws IOException {
        try {
            //Loads the FXML file "Area.fxml" to generate the UI.
            Parent root = FXMLLoader.load(getClass().getResource("Area.fxml"));

            Scene scene = new Scene(root);
            stage.setTitle("Pokemon");
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
